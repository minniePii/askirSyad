# syadgpt

Simple Next.js app. Add OPENAI_API_KEY in Vercel env or .env.local
