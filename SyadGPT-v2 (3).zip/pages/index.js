import { useState, useRef, useEffect } from 'react';

export default function Home() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const listRef = useRef(null);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages, open]);

  async function sendMessage(e) {
    e?.preventDefault();
    if (!input.trim()) return;
    const userMsg = { role: 'user', content: input.trim() };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg] })
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || 'Server error');
      }
      const data = await res.json();
      setMessages(m => [...m, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setMessages(m => [...m, { role: 'assistant', content: 'Sorry — I failed to fetch a reply.' }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <main className="w-full max-w-3xl px-6 py-12">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold">syadgpt</h1>
          <p className="mt-2 text-gray-600">your friendly ai companion</p>
        </div>

        <div className="rounded-lg p-8 bg-white shadow-md">
          <p className="text-gray-700">Welcome — click the chat bubble at the bottom right to start a conversation.</p>
        </div>
      </main>

      {/* Floating chat button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-6 right-6 bg-indigo-600 text-white rounded-full w-14 h-14 flex items-center justify-center text-2xl shadow-lg hover:scale-105 transition"
        aria-label="Open chat"
      >
        💬
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-20 right-6 w-80 max-h-96 bg-white shadow-2xl rounded-xl flex flex-col overflow-hidden">
          <div className="px-4 py-3 bg-indigo-600 text-white font-semibold">Ask syadgpt</div>
          <div ref={listRef} className="flex-1 overflow-auto p-3 space-y-2">
            {messages.length === 0 && <div className="text-gray-500 text-sm">Say hi — ask anything.</div>}
            {messages.map((m,i) => (
              <div key={i} className={`p-2 rounded ${m.role==='user' ? 'bg-indigo-50 text-right' : 'bg-gray-100 text-left'}`}>
                <div className="text-sm">{m.content}</div>
              </div>
            ))}
            {loading && <div className="text-sm text-gray-500">Thinking...</div>}
          </div>

          <form onSubmit={sendMessage} className="p-3 border-t">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                className="flex-1 border rounded px-3 py-2 text-sm"
                placeholder="Ask Irsyad..."
              />
              <button type="submit" disabled={loading} className="bg-indigo-600 text-white px-3 rounded">
                {loading ? '…' : 'Send'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
